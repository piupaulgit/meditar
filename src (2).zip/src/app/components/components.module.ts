import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { RouterModule } from "@angular/router";
import { IonicModule } from "@ionic/angular";
import { SideNavComponent } from "./side-nav/side-nav.component";

@NgModule({
  declarations: [SideNavComponent],
  imports: [CommonModule, RouterModule, IonicModule],
  exports: [SideNavComponent]
})
export class ComponentsModule {}
